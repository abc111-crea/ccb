import streamlit as st
def app():
    st.title("Shortest Path Creator")
    markdown = """This is a small project which made for identifying a shortest path in a visual map. 

                Please chose the content in the Navigation box"""

    st.markdown(markdown)